export default interface ProductCard {
  id: string;
  title: string;
  price: number;
  image: string;
  color: string;
}

